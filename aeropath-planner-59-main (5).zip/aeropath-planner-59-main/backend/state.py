"""
AMAN State Management — Single Source of Truth
Storage ONLY. No AI or physics logic.
"""

import time
from collections import deque
from typing import Dict, List, Optional
from models import Aircraft, RunwayStatus, AircraftStatus
from config import RUNWAYS, RUNWAY_CAPACITY_PER_HOUR


class ATCState:
    def __init__(self):
        self.reset()

    def reset(self) -> None:
        self.aircraft: Dict[str, Aircraft] = {}
        self.runways: Dict[str, RunwayStatus] = {}
        self.simulation_time: float = 0
        self.tick_count: int = 0
        self.start_time: float = time.time()
        self.landed_count: int = 0
        self.peak_hour_enabled: bool = False
        self.arrival_rate: float = 20

        # Event-driven analytics
        self.landing_events: deque = deque(maxlen=3600)
        self.landing_delay_events: deque = deque(maxlen=500)
        self._holding_aircraft: set = set()
        self._current_delays: Dict[str, float] = {}
        self.analytics_snapshots: List[dict] = []
        self._snapshot_interval: int = 5

        for runway_id in RUNWAYS.keys():
            self.runways[runway_id] = RunwayStatus(
                id=runway_id, occupied=False,
                occupying_aircraft=None, occupying_aircraft_id=None,
                clearance_lock=False, last_cleared_time=0.0, occupied_time=0.0,
            )

    # =========================================================================
    # AIRCRAFT — get_active_aircraft returns ALL (no status filter)
    # =========================================================================

    def add_aircraft(self, aircraft: Aircraft) -> None:
        self.aircraft[aircraft.id] = aircraft

    def remove_aircraft(self, aircraft_id: str) -> Optional[Aircraft]:
        aircraft = self.aircraft.pop(aircraft_id, None)
        if aircraft:
            for runway in self.runways.values():
                if runway.occupying_aircraft_id == aircraft_id:
                    self._do_clear_runway(runway.id)
            self._current_delays.pop(aircraft_id, None)
            self._holding_aircraft.discard(aircraft_id)
        return aircraft

    def get_aircraft(self, aircraft_id: str) -> Optional[Aircraft]:
        return self.aircraft.get(aircraft_id)

    def get_active_aircraft(self) -> List[Aircraft]:
        """Return ALL aircraft — do NOT filter by status."""
        return list(self.aircraft.values())

    def get_aircraft_by_runway(self, runway_id: str) -> List[Aircraft]:
        return [ac for ac in self.aircraft.values() if ac.runway == runway_id]

    # =========================================================================
    # RUNWAYS
    # =========================================================================

    def get_runway(self, runway_id: str) -> Optional[RunwayStatus]:
        return self.runways.get(runway_id)

    def set_runway_occupied(self, runway_id: str, aircraft: Aircraft) -> bool:
        runway = self.runways.get(runway_id)
        if not runway or runway.occupied:
            return False
        runway.occupied = True
        runway.occupying_aircraft_id = aircraft.id
        runway.occupying_aircraft = aircraft.callsign
        runway.clearance_lock = True
        runway.last_cleared_time = self.simulation_time
        return True

    def clear_runway(self, runway_id: str) -> None:
        """Clear runway and record landing event."""
        self._do_clear_runway(runway_id)
        self.landed_count += 1
        self.landing_events.append(self.simulation_time)

    def _do_clear_runway(self, runway_id: str) -> None:
        runway = self.runways.get(runway_id)
        if runway:
            runway.occupied = False
            runway.occupying_aircraft_id = None
            runway.occupying_aircraft = None
            runway.clearance_lock = False

    def is_runway_occupied(self, runway_id: str) -> bool:
        runway = self.runways.get(runway_id)
        return runway.occupied if runway else True

    # =========================================================================
    # ANALYTICS RECORDING
    # =========================================================================

    def record_delay(self, aircraft_id: str, delay_seconds: float) -> None:
        self._current_delays[aircraft_id] = delay_seconds

    def record_landing_delay(self, delay_seconds: float) -> None:
        self.landing_delay_events.append((self.simulation_time, delay_seconds))

    def record_holding_entry(self, aircraft_id: str) -> None:
        if aircraft_id not in self._holding_aircraft:
            self._holding_aircraft.add(aircraft_id)

    def record_holding_exit(self, aircraft_id: str) -> None:
        self._holding_aircraft.discard(aircraft_id)

    # =========================================================================
    # SIMULATION CONTROL
    # =========================================================================

    def increment_tick(self) -> int:
        self.tick_count += 1
        self.simulation_time += 1.0

        # Track runway occupied time
        for runway in self.runways.values():
            if runway.occupied:
                runway.occupied_time += 1.0

        if self.tick_count % self._snapshot_interval == 0:
            self._take_analytics_snapshot()
        return self.tick_count

    # =========================================================================
    # DERIVED ANALYTICS
    # =========================================================================

    def get_avg_delay(self) -> float:
        delays = [v for v in self._current_delays.values() if v > 0]
        return sum(delays) / len(delays) if delays else 0.0

    def get_max_delay(self) -> float:
        delays = list(self._current_delays.values())
        return max(delays) if delays else 0.0

    def get_landings_per_hour(self) -> float:
        if self.simulation_time < 10:
            return 0.0
        window_start = max(0.0, self.simulation_time - 3600.0)
        while self.landing_events and self.landing_events[0] < window_start:
            self.landing_events.popleft()
        count = len(self.landing_events)
        elapsed_hours = min(self.simulation_time, 3600.0) / 3600.0
        return count / elapsed_hours if elapsed_hours > 0 else 0.0

    def get_arrival_pressure(self) -> float:
        active = len([ac for ac in self.aircraft.values()
                      if ac.status not in (AircraftStatus.LANDED,)])
        return (active / RUNWAY_CAPACITY_PER_HOUR) * 100 if RUNWAY_CAPACITY_PER_HOUR > 0 else 0.0

    def get_queue_length(self) -> int:
        return sum(1 for ac in self.aircraft.values()
                   if ac.status in (AircraftStatus.HOLDING, AircraftStatus.APPROACH)
                   and ac.predicted_delay > 0)

    def get_holding_count(self) -> int:
        return len(self._holding_aircraft)

    def get_runway_utilization(self, runway_id: str) -> float:
        runway = self.runways.get(runway_id)
        if runway and self.simulation_time > 0:
            return min(100.0, (runway.occupied_time / self.simulation_time) * 100.0)
        return 0.0

    def _update_runway_stats(self) -> None:
        for runway_id, runway in self.runways.items():
            runway.utilization = self.get_runway_utilization(runway_id)
            runway.queue_length = len([ac for ac in self.aircraft.values()
                                       if ac.runway == runway_id
                                       and ac.status not in (AircraftStatus.LANDED,)])

    def _take_analytics_snapshot(self) -> None:
        self._update_runway_stats()
        self.analytics_snapshots.append({
            "time": self.simulation_time,
            "minute": int(self.simulation_time / 60),
            "active_count": len([ac for ac in self.aircraft.values()
                                 if ac.status != AircraftStatus.LANDED]),
            "landed_count": self.landed_count,
            "avg_delay": round(self.get_avg_delay() / 60, 2),
            "max_delay": round(self.get_max_delay() / 60, 2),
            "landings_per_hour": round(self.get_landings_per_hour(), 1),
            "queue_length": self.get_queue_length(),
            "holding_count": self.get_holding_count(),
            "arrival_pressure": round(self.get_arrival_pressure(), 1),
            "utilization_09L": round(self.get_runway_utilization("09L"), 1),
            "utilization_09R": round(self.get_runway_utilization("09R"), 1),
        })
        if len(self.analytics_snapshots) > 720:
            self.analytics_snapshots = self.analytics_snapshots[-720:]

    def to_response(self) -> dict:
        """API response — sorted by sequence_position."""
        self._update_runway_stats()

        all_ac = [ac for ac in self.aircraft.values()
                  if ac.status != AircraftStatus.LANDED]
        all_ac.sort(key=lambda a: a.sequence_position)

        avg_delay = self.get_avg_delay()
        max_delay = self.get_max_delay()
        lph = self.get_landings_per_hour()
        util_09L = self.get_runway_utilization("09L")
        util_09R = self.get_runway_utilization("09R")

        return {
            "aircraft": [ac.to_frontend_dict() for ac in all_ac],
            "runways": [rwy.to_frontend_dict() for rwy in self.runways.values()],
            "simulation_time": self.simulation_time,
            "tick_count": self.tick_count,
            "analytics": {
                "total_active": len(all_ac),
                "total_landed": self.landed_count,
                "avg_delay": round(avg_delay / 60, 1),
                "max_delay": round(max_delay / 60, 1),
                "runway_capacity": RUNWAY_CAPACITY_PER_HOUR,
                "landings_per_hour": round(lph, 1),
                "arrival_rate": self.arrival_rate,
                "peak_hour_enabled": self.peak_hour_enabled,
                "queue_length_09L": self.runways["09L"].queue_length,
                "queue_length_09R": self.runways["09R"].queue_length,
                "arrival_pressure": round(self.get_arrival_pressure(), 1),
                "queue_length": self.get_queue_length(),
                "holding_count": self.get_holding_count(),
                "runway_utilization": round(max(util_09L, util_09R), 1),
            }
        }


atc_state = ATCState()
