"""
AMAN AI Logic — Sequencing decisions ONLY.
No movement. No state transitions. Those are in physics.py.

Rules:
- Group by runway, sort by ETT, assign RTA slots
- Speed reduction FIRST, holding LAST RESORT
- Routes assigned ONCE — never reset every tick
- Only first in sequence cleared for landing when runway free + distance <= 6 NM
"""

import math
from typing import List, Tuple, Optional, Dict
from models import (
    Aircraft, AircraftStatus, WakeCategory, WAKE_SEPARATION_SEC,
    haversine_distance, calculate_bearing, offset_position,
)
from state import atc_state
from config import (
    RUNWAYS, OPTIMIZATION_ZONE_NM, SEPARATION_TIME_SEC,
    SPEED_PROFILES, FINAL_APPROACH_START_NM, MIN_SEPARATION_NM,
    DELAY_SMALL_THRESHOLD_SEC, DELAY_MEDIUM_THRESHOLD_SEC, DELAY_HOLD_RELEASE_SEC,
)


def run_sequencing() -> None:
    """Main entry — called every tick BEFORE physics."""
    aircraft_list = atc_state.get_active_aircraft()
    if not aircraft_list:
        return

    # Refresh distances
    for ac in aircraft_list:
        ac.distance_to_threshold = ac.remaining_distance_nm()

    # Group by runway
    groups: Dict[str, List[Aircraft]] = {"09L": [], "09R": []}
    for ac in aircraft_list:
        if ac.runway in groups and ac.status != AircraftStatus.LANDED:
            groups[ac.runway].append(ac)

    for runway_id, acs in groups.items():
        _sequence_runway(runway_id, acs)

    _detect_conflicts([ac for ac in aircraft_list if ac.status != AircraftStatus.LANDED])

    # Write back
    for ac in aircraft_list:
        atc_state.aircraft[ac.id] = ac


def _get_separation(leader: Aircraft, follower: Aircraft) -> float:
    return WAKE_SEPARATION_SEC.get(
        leader.wake_category, {}
    ).get(follower.wake_category, SEPARATION_TIME_SEC)


def _sequence_runway(runway_id: str, aircraft: List[Aircraft]) -> None:
    if not aircraft:
        return
    rc = RUNWAYS.get(runway_id)
    if not rc:
        return
    threshold = (rc["threshold_lat"], rc["threshold_lon"])

    # Separate committed (LANDING/ROLLOUT) from sequenceable (APPROACH/HOLDING)
    committed = [ac for ac in aircraft if ac.status in (AircraftStatus.LANDING, AircraftStatus.ROLLOUT)]
    sequenceable = [ac for ac in aircraft if ac.status in (AircraftStatus.APPROACH, AircraftStatus.HOLDING)]

    # Sort sequenceable by ETT
    for ac in sequenceable:
        ac._ett = ac.compute_ett()
    sequenceable.sort(key=lambda a: a._ett)

    # Assign sequence numbers to committed first
    for idx, ac in enumerate(committed):
        ac.sequence_position = idx + 1
        ac.queue_position = 0

    runway_occupied = len(committed) > 0

    # Base RTA — when runway will be free
    base_rta = atc_state.simulation_time
    if runway_occupied:
        for ac in committed:
            if ac.status == AircraftStatus.LANDING:
                t = (ac.distance_to_threshold / max(ac.speed, 1)) * 3600 + 60
                base_rta = atc_state.simulation_time + t
            elif ac.status == AircraftStatus.ROLLOUT:
                base_rta = atc_state.simulation_time + 30
    else:
        rwy = atc_state.get_runway(runway_id)
        if rwy and rwy.last_cleared_time > 0:
            since = atc_state.simulation_time - rwy.last_cleared_time
            if since < SEPARATION_TIME_SEC:
                base_rta = atc_state.simulation_time + (SEPARATION_TIME_SEC - since)

    # Assign RTA slots
    prev_ac: Optional[Aircraft] = committed[-1] if committed else None
    prev_rta = base_rta

    for idx, ac in enumerate(sequenceable):
        seq_num = len(committed) + idx + 1
        ac.sequence_position = seq_num
        ac.queue_position = idx

        ett = ac._ett

        if idx == 0:
            rta_abs = base_rta
        else:
            sep = _get_separation(prev_ac, ac) if prev_ac else SEPARATION_TIME_SEC
            rta_abs = prev_rta + sep

        rta_from_now = max(0.0, rta_abs - atc_state.simulation_time)
        ac.rta = rta_from_now
        delay = max(0.0, rta_from_now - ett)
        ac.predicted_delay = delay
        atc_state.record_delay(ac.id, delay)

        # Compute optimal speed
        ac.optimal_speed = _compute_optimal_speed(ac, rta_from_now)

        prev_rta = rta_abs
        prev_ac = ac

        # === Decision ===
        # Already has a landing route assigned? Don't touch it.
        if getattr(ac, '_landing_cleared', False):
            continue

        if ac.distance_to_threshold > OPTIMIZATION_ZONE_NM:
            # Outside TMA — normal approach
            _set_approach(ac, runway_id)
        elif not runway_occupied and idx == 0 and delay < 5:
            # First, runway free, no delay → clear for landing
            if ac.distance_to_threshold <= FINAL_APPROACH_START_NM:
                _clear_landing(ac, runway_id, threshold, rc)
                runway_occupied = True
            else:
                _set_approach(ac, runway_id)
        else:
            _absorb_delay(ac, runway_id, threshold, delay, seq_num)


def _compute_optimal_speed(ac: Aircraft, rta_from_now: float) -> float:
    if rta_from_now <= 0 or ac.distance_to_threshold <= 0:
        return ac.speed
    required = (ac.distance_to_threshold / rta_from_now) * 3600
    profile = SPEED_PROFILES.get("APPROACH", SPEED_PROFILES["APPROACH"])
    return max(profile["min"], min(profile["max"], required))


# =============================================================================
# STATE ASSIGNMENTS — routes assigned ONCE, never reset
# =============================================================================

def _set_approach(ac: Aircraft, runway_id: str) -> None:
    """Normal approach — keep user heading, no route override."""
    if ac.status in (AircraftStatus.LANDING, AircraftStatus.ROLLOUT):
        return
    # If currently holding with active route, let it finish
    if ac.status == AircraftStatus.HOLDING and ac.route and ac.current_waypoint_index < len(ac.route):
        return
    ac.status = AircraftStatus.APPROACH
    ac.aman_heading_override = False
    ac.delay_mode = "speed"


def _clear_landing(ac: Aircraft, runway_id: str, threshold: Tuple, rc: dict) -> None:
    """Clear for landing — assign route [current → threshold → exit], lock runway."""
    ac.status = AircraftStatus.LANDING
    ac.predicted_delay = 0
    ac.delay_mode = "speed"
    ac.aman_heading_override = True
    ac._landing_cleared = True
    ac.instruction = f"{ac.callsign}, runway {runway_id} cleared to land. Wind calm."

    # Generate route ONCE: approach → threshold → exit
    route = []
    steps = max(4, int(ac.distance_to_threshold / 1.5))
    for i in range(1, steps + 1):
        t = i / steps
        lat = ac.lat + (threshold[0] - ac.lat) * t
        lon = ac.lon + (threshold[1] - ac.lon) * t
        alt = max(0, ac.altitude * (1 - t))
        route.append([lat, lon, alt])
    route[-1] = [threshold[0], threshold[1], 0]

    # Rollout segment
    exit_lat, exit_lon = rc["exit_lat"], rc["exit_lon"]
    for i in range(1, 5):
        t = i / 4
        lat = threshold[0] + (exit_lat - threshold[0]) * t
        lon = threshold[1] + (exit_lon - threshold[1]) * t
        route.append([lat, lon, 0])

    ac.route = route
    ac.current_waypoint_index = 0
    atc_state.set_runway_occupied(runway_id, ac)


def _absorb_delay(ac: Aircraft, runway_id: str, threshold: Tuple, delay: float, seq_num: int) -> None:
    """
    3-tier delay absorption. Routes only generated when needed.
    Tier 1: Speed reduction (primary)
    Tier 2: Trombone vectoring (medium delay)
    Tier 3: Holding (last resort, delay > 3 min)
    """

    # Holding release check
    if ac.delay_mode == "holding" and delay < DELAY_HOLD_RELEASE_SEC:
        ac.delay_mode = "speed"
        ac.status = AircraftStatus.APPROACH
        ac.aman_heading_override = False
        ac.route = []
        ac.current_waypoint_index = 0
        ac.instruction = f"{ac.callsign}, #{seq_num}. Holding cancelled. Resume approach."
        atc_state.record_holding_exit(ac.id)
        return

    # Tier 1: Speed reduction
    profile = SPEED_PROFILES["APPROACH"]
    time_at_min = (ac.distance_to_threshold / profile["min"]) * 3600 if profile["min"] > 0 else 0
    max_speed_absorb = time_at_min - ac._ett

    if delay <= max(max_speed_absorb, DELAY_SMALL_THRESHOLD_SEC):
        ac.delay_mode = "speed"
        ac.status = AircraftStatus.APPROACH
        ac.aman_heading_override = False
        ac.instruction = (
            f"{ac.callsign}, #{seq_num}. Reduce speed {int(ac.optimal_speed)}kt. "
            f"{int(delay)}s delay."
        )
        return

    # Tier 2: Trombone
    if delay <= DELAY_MEDIUM_THRESHOLD_SEC:
        ac.delay_mode = "trombone"
        # Only generate route if none or completed
        if not ac.route or ac.current_waypoint_index >= len(ac.route) - 1:
            ac.route = _generate_trombone(ac, threshold, delay, runway_id)
            ac.current_waypoint_index = 0
        ac.status = AircraftStatus.HOLDING
        ac.aman_heading_override = True
        ac.instruction = (
            f"{ac.callsign}, #{seq_num}. Vectoring for spacing. "
            f"{round(delay/60,1)}min delay."
        )
        return

    # Tier 3: Holding (last resort)
    prev_mode = ac.delay_mode
    ac.delay_mode = "holding"
    if not ac.route or ac.current_waypoint_index >= len(ac.route) - 1 or prev_mode != "holding":
        ac.route = _generate_trombone(ac, threshold, delay, runway_id)
        ac.current_waypoint_index = 0
        atc_state.record_holding_entry(ac.id)
    ac.status = AircraftStatus.HOLDING
    ac.aman_heading_override = True
    ac.instruction = (
        f"{ac.callsign}, #{seq_num}. Hold. {round(delay/60,1)}min delay. "
        f"Maintain {int(ac.altitude)}ft."
    )


def _generate_trombone(ac: Aircraft, threshold: Tuple, delay_sec: float, runway_id: str) -> List[List[float]]:
    """
    Smooth trombone route: lateral offset → downwind → base → FAF → threshold.
    NOT circular. Ends at runway threshold.
    """
    rc = RUNWAYS.get(runway_id)
    if not rc:
        return [[threshold[0], threshold[1], 50]]

    rwy_hdg = rc["heading"]
    hold_speed = SPEED_PROFILES["HOLDING"]["target"]
    extra_nm = (delay_sec / 3600) * hold_speed
    downwind_nm = max(3.0, min(25.0, extra_nm / 2.0))

    offset_dir = 1 if runway_id == "09L" else -1
    lat_bearing = (rwy_hdg + 90 * offset_dir) % 360
    opp_lat_bearing = (lat_bearing + 180) % 360
    approach_bearing = (rwy_hdg + 180) % 360
    lat_offset_nm = 3.0

    faf = offset_position(threshold[0], threshold[1], approach_bearing, FINAL_APPROACH_START_NM)
    hold_alt = min(ac.altitude, 5000)

    route = []
    # 1: Lateral offset
    abeam = offset_position(ac.lat, ac.lon, lat_bearing, lat_offset_nm)
    route.append([abeam[0], abeam[1], hold_alt])
    # 2: Downwind
    dw = offset_position(abeam[0], abeam[1], approach_bearing, downwind_nm)
    route.append([dw[0], dw[1], 4000])
    # 3: Base turn
    base = offset_position(dw[0], dw[1], opp_lat_bearing, lat_offset_nm)
    route.append([base[0], base[1], 3500])
    # 4: FAF intercept
    route.append([faf[0], faf[1], 2500])
    # 5: Threshold
    route.append([threshold[0], threshold[1], 50])

    return route


# =============================================================================
# CONFLICT DETECTION
# =============================================================================

def _detect_conflicts(aircraft: List[Aircraft]) -> None:
    for i, ac1 in enumerate(aircraft):
        min_sep = float('inf')
        conflict = False
        for j, ac2 in enumerate(aircraft):
            if i == j:
                continue
            h = haversine_distance(ac1.lat, ac1.lon, ac2.lat, ac2.lon)
            v = abs(ac1.altitude - ac2.altitude)
            if h < MIN_SEPARATION_NM and v < 1000:
                conflict = True
            min_sep = min(min_sep, h)
        ac1.has_conflict = conflict
        ac1.safety_percent = min(100, max(0, (min_sep / MIN_SEPARATION_NM) * 100)) if len(aircraft) > 1 else 100


def process_state_transitions() -> None:
    """Post-physics cleanup: remove LANDED aircraft, clear runways."""
    landed = [(ac.id, ac.runway) for ac in atc_state.get_active_aircraft()
              if ac.status == AircraftStatus.LANDED]
    for ac_id, rwy_id in landed:
        atc_state.clear_runway(rwy_id)
        atc_state.remove_aircraft(ac_id)
