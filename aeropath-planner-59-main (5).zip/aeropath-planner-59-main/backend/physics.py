"""
AMAN Physics Engine — Movement + State Transitions ONLY.
No sequencing decisions. Those are in ai_logic.py.

Order per tick:
1. update_speed
2. update_heading
3. update_position
4. check_waypoint_capture
5. check_state_transitions
6. update_eta
"""

from models import (
    Aircraft, AircraftStatus,
    haversine_distance, calculate_bearing, offset_position, normalize_heading,
)
from state import atc_state
from config import (
    RUNWAYS, MAX_TURN_RATE_DEG_SEC, SPEED_TRANSITION_RATE,
    SPEED_PROFILES, WAYPOINT_CAPTURE_NM, THRESHOLD_TOLERANCE_NM,
    DESCENT_RATE_FT_PER_NM, FINAL_DESCENT_RATE,
)


def run_physics(delta_time: float = 1.0) -> None:
    for ac in atc_state.get_active_aircraft():
        if ac.status == AircraftStatus.LANDED:
            ac.speed = 0
            continue
        if ac.source == "adsb":
            ac.distance_to_threshold = ac.remaining_distance_nm()
            _update_eta(ac)
            continue
        _update_speed(ac, delta_time)
        _update_heading(ac, delta_time)
        _update_position(ac, delta_time)
        _update_altitude(ac, delta_time)
        _check_waypoint_capture(ac)
        _check_state_transitions(ac)
        ac.distance_to_threshold = ac.remaining_distance_nm()
        _update_eta(ac)
        atc_state.aircraft[ac.id] = ac


def _update_speed(ac: Aircraft, dt: float) -> None:
    target = _get_target_speed(ac)
    diff = target - ac.speed
    max_change = SPEED_TRANSITION_RATE * dt
    if abs(diff) <= max_change:
        ac.speed = target
    elif diff > 0:
        ac.speed += max_change
    else:
        ac.speed -= max_change
    ac.speed = max(0, ac.speed)


def _get_target_speed(ac: Aircraft) -> float:
    if ac.status in (AircraftStatus.APPROACH, AircraftStatus.HOLDING):
        if ac.optimal_speed > 0:
            return ac.optimal_speed
    if ac.status == AircraftStatus.APPROACH:
        return SPEED_PROFILES["APPROACH"]["target"]
    if ac.status == AircraftStatus.HOLDING:
        return SPEED_PROFILES["HOLDING"]["target"]
    if ac.status == AircraftStatus.LANDING:
        return SPEED_PROFILES["LANDING"]["target"]
    if ac.status == AircraftStatus.ROLLOUT:
        decel = SPEED_PROFILES["ROLLOUT"]["decel_rate"]
        return max(SPEED_PROFILES["ROLLOUT"]["taxi"], ac.speed - decel)
    return 0


def _update_heading(ac: Aircraft, dt: float) -> None:
    target = _get_target_heading(ac)
    if target is None:
        return
    diff = target - ac.heading
    if diff > 180:
        diff -= 360
    elif diff < -180:
        diff += 360
    max_turn = MAX_TURN_RATE_DEG_SEC * dt
    if abs(diff) <= max_turn:
        ac.heading = target
    elif diff > 0:
        ac.heading += max_turn
    else:
        ac.heading -= max_turn
    ac.heading = normalize_heading(ac.heading)


def _get_target_heading(ac: Aircraft) -> float:
    rc = RUNWAYS.get(ac.runway)
    if not rc:
        return ac.heading

    # Rollout/Landing: locked to runway heading
    if ac.status in (AircraftStatus.ROLLOUT, AircraftStatus.LANDING):
        # If has route, follow waypoints; else runway heading
        if ac.route and ac.current_waypoint_index < len(ac.route):
            wp = ac.route[ac.current_waypoint_index]
            return calculate_bearing(ac.lat, ac.lon, wp[0], wp[1])
        return rc["heading"]

    # AMAN route override (holding/trombone)
    if ac.aman_heading_override and ac.route and ac.current_waypoint_index < len(ac.route):
        wp = ac.route[ac.current_waypoint_index]
        return calculate_bearing(ac.lat, ac.lon, wp[0], wp[1])

    # Normal approach — respect user heading far out, head to threshold when close
    if ac.status == AircraftStatus.APPROACH:
        if ac.distance_to_threshold < 20:
            return calculate_bearing(ac.lat, ac.lon, rc["threshold_lat"], rc["threshold_lon"])
        return ac.user_heading

    return calculate_bearing(ac.lat, ac.lon, rc["threshold_lat"], rc["threshold_lon"])


def _update_position(ac: Aircraft, dt: float) -> None:
    if ac.speed <= 0:
        return
    dist_nm = (ac.speed / 3600) * dt
    new_lat, new_lon = offset_position(ac.lat, ac.lon, ac.heading, dist_nm)
    ac.lat = new_lat
    ac.lon = new_lon


def _update_altitude(ac: Aircraft, dt: float) -> None:
    if ac.status in (AircraftStatus.ROLLOUT, AircraftStatus.LANDED):
        ac.altitude = 0
        return
    target = _target_altitude(ac)
    if ac.altitude > target:
        rate = FINAL_DESCENT_RATE if ac.status == AircraftStatus.LANDING else DESCENT_RATE_FT_PER_NM
        descent = (ac.speed / 3600) * dt * rate
        ac.altitude = max(target, ac.altitude - descent)
    elif ac.altitude < target:
        ac.altitude = min(target, ac.altitude + 100 * dt)


def _target_altitude(ac: Aircraft) -> float:
    d = ac.distance_to_threshold
    if ac.status == AircraftStatus.APPROACH:
        return max(3500, 10000 - max(0, 20 - d) * 325) if d <= 20 else 10000
    if ac.status == AircraftStatus.HOLDING:
        return 4000
    if ac.status == AircraftStatus.LANDING:
        return max(0, d * 500)
    return 0


def _check_waypoint_capture(ac: Aircraft) -> None:
    """Advance waypoint index when aircraft reaches current waypoint (0.08 NM)."""
    if not ac.route or ac.current_waypoint_index >= len(ac.route):
        return
    wp = ac.route[ac.current_waypoint_index]
    dist = haversine_distance(ac.lat, ac.lon, wp[0], wp[1])
    if dist < WAYPOINT_CAPTURE_NM:
        ac.current_waypoint_index += 1


def _check_state_transitions(ac: Aircraft) -> None:
    """Position-based state transitions."""
    rc = RUNWAYS.get(ac.runway)
    if not rc:
        return

    thresh = (rc["threshold_lat"], rc["threshold_lon"])
    exit_pos = (rc["exit_lat"], rc["exit_lon"])
    dist_thresh = haversine_distance(ac.lat, ac.lon, thresh[0], thresh[1])
    dist_exit = haversine_distance(ac.lat, ac.lon, exit_pos[0], exit_pos[1])

    # LANDING → ROLLOUT at threshold
    if ac.status == AircraftStatus.LANDING and dist_thresh < THRESHOLD_TOLERANCE_NM:
        ac.status = AircraftStatus.ROLLOUT
        ac.altitude = 0
        ac.instruction = f"{ac.callsign}, touchdown runway {ac.runway}. Reduce speed."
        atc_state.record_landing_delay(ac.predicted_delay)

    # ROLLOUT → LANDED at exit or stopped
    if ac.status == AircraftStatus.ROLLOUT:
        taxi = SPEED_PROFILES["ROLLOUT"]["taxi"]
        if dist_exit < THRESHOLD_TOLERANCE_NM or ac.speed <= taxi:
            ac.status = AircraftStatus.LANDED
            ac.speed = 0
            ac.altitude = 0
            ac.eta = 0
            ac.instruction = f"{ac.callsign}, vacated runway {ac.runway}. Contact ground."


def _update_eta(ac: Aircraft) -> None:
    """ETA = distance / speed * 3600. Decreases continuously. Zero on rollout/landed."""
    if ac.status in (AircraftStatus.ROLLOUT, AircraftStatus.LANDED):
        ac.eta = 0
        return
    if ac.speed <= 0:
        ac.eta = 0
        return
    ac.eta = (ac.distance_to_threshold / ac.speed) * 3600
